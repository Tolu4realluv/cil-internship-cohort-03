# i am using the BeautifulSoup library which is not available in AWS so i order to get this done, i installed the bs4 and requests 
# libraries into my deployment folder then archived it all in a single file and deploy to AWS.
 
#import the necessary libraries
from bs4 import BeautifulSoup
import requests


def lambda_handler(event, context):
  urls = ['https://cecureintel.com/']
  for url in urls:
    html_content = requests.get(url).text
    soup = BeautifulSoup(html_content, "lxml")
    print(soup.h1.text)









